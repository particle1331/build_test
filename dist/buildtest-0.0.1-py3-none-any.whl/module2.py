class Tanga:
    def __init__(self):
        pass
    